#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
	cout << "Nom: Paul-Etienne Paquin";
	cout << endl;
	cout << endl;
	cout << "Age: 20 ans";
	cout << endl;
	cout << endl;
	cout << "Diplome: Secondaire 5";
	cout << endl;
	cout << endl;
	cout << "Occupation l'hiver passe: Travailler chez Amnesia et le CCSE Maisonneuve";
	cout << endl;
	cout << endl;
	cout << "Sports: Ski, Musculation, Course";
	cout << endl;
	cout << endl;
	cout << "Hobbys: Jeux video, sports, musique, lecture";

	_getch();
}