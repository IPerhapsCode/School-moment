/*
	Version		: 3.1
	Description	: Programme qui ajoute les taxes � un montant lu au clavier.
				  Ce programme permet aussi d'ajouter un pourboire.
				  Ce programme affiche les d�tails des taxes et pourboire ainsi que le total.

	Ajouts		: Gestion d'un pourboire optionnel de 12%, 15% ou 18%
				: Affichage optionnel des informations reli�es aux pourboires.
*/

#include <iostream>	// pour le cout et le cin
#include <iomanip>	// pour les manipulateurs du cout: fixed, setprecision(), setw(), ...
#include <conio.h>	// pour le _getch()

using namespace std; // Pour ne pas �tre oblig� d'�crire std::cout

int main ()
{
	// CONSTANTES POUR L'AFFICHAGE
	const int tab = 7;

	// CONSTANTES
	const double TVQ = 0.09975, TPS = 0.05, TIP1 = 0.12, TIP2 = 0.15, TIP3 = 0.18;
	const string titre = "D\x82tails de la facture";

	// VARIABLES
	double totalAvantTaxe, tps, tvq, tip, totalApresTaxe;
	char r�ponse1, r�ponse2;
    bool avecTip;


	// INPUT
	cout << "Quel est le montant ? : ";
	cin >> totalAvantTaxe;
	
	cout << endl << "Voulez-vous inclure un pourboire ? (O/N) : ";
	r�ponse1 = _getch();
	r�ponse1 = toupper(r�ponse1);
	cout << r�ponse1 << endl;

	avecTip = r�ponse1 == 'O';
	if (avecTip)
	{
		cout << endl << "Choix du pourboire ? " << "( 1 = " << TIP1*100 << "% , 2 = " << TIP2*100 << "% , 3 = " << TIP3*100 << "% ) : ";
		r�ponse2 = _getche();
		cout << endl;
	}


	// CALCULS DES �L�MENTS DE LA FACTURE
	tvq = totalAvantTaxe * TVQ;
	tps = totalAvantTaxe * TPS;
	
	if (avecTip)
		if (r�ponse2 == '1')
			tip = totalAvantTaxe * TIP1;
		else
			if (r�ponse2 == '2')
			    tip = totalAvantTaxe * TIP2;
		    else
				if (r�ponse2 == '3')
			        tip = totalAvantTaxe * TIP3;
		        else
			        tip = 0;
	else
		tip = 0;

	totalApresTaxe = totalAvantTaxe + tvq + tps + tip;


	// AFFICHAGE DE LA FACTURE
	cout << fixed << setprecision(2) << right << "\n\n";
	cout << titre << "\n" << setfill('=') << setw(titre.size()) << "" << setfill(' ') << "\n\n";

	cout << "Montant brute : " << totalAvantTaxe << " $" << "\n\n";
	cout << " tps : " << setw(tab) << tps << " $" << "\n\n";
	cout << " tvq : " << setw(tab) << tvq << " $" << "\n\n";
	if (avecTip)
		cout << " tip : " << setw(tab) << tip << " $" << "\n\n";
	cout << "Montant total : " << totalApresTaxe << " $" << "\n";


	_getch();
}