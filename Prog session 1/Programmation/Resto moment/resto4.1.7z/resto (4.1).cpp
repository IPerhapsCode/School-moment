/*
	Version		: 4.1
	Description	: Programme qui ajoute les taxes � un montant lu au clavier.
				  Ce programme permet aussi d'ajouter de plusieurs fa�on un pourboire.
				  Ce programme affiche les d�tails des taxes et pourboire ainsi que le total de la facture.

	Ajouts		: Le programme permet de choisir al�atoirement un pourboire entre un minimum et un maximum
				: Utilisation de fonction rand() et srand()

	� Faire     : Validation de certaines donn�es lues � l'entr�e
*/

#include <iostream>			// cout et cin
#include <iomanip>			// fixed, setprecision(), setw(), ...
#include <conio.h>			// _getch() et _getche()
#include "../../cvm 21.h"	// clrscr(), wherex(), wherey(), gotoxy()

using namespace std;

int main ()
{
	// CONSTANTES
	const int tab = 7;
	const double TVQ = 0.09975, TPS = 0.05, TIP1 = 0.12, TIP2 = 0.15, TIP3 = 0.18;

	const unsigned int MINTip = 5, MAXTip = 50; // converti en % plus tard

	// VARIABLES
	size_t x, y;	// pour gotoxy();

	double TIP4, totalAvantTaxe, tps, tvq, tip, totalApresTaxe;
	char avecTip, choix, recommencer;

	srand( (unsigned int) time(NULL) ); // initialisation du g�n�rateur de nombre al�atoire avec l'heure en seconde

	cout << fixed;

	// LIRE ... CALCULER ... AFFICHER ... RECOMMENCER
	do
	{
		// 1) LIRE LES INFORMATIONS DE L'USAGER
		cout << endl << "Quel est le montant ? : ";	// � faire : valider l'entr�e
		cin >> totalAvantTaxe;

		cout << endl << "Voulez-vous inclure un pourboire ? (O/N) : ";
		x = wherex(); y = wherey();
		for (avecTip = ' '; avecTip != 'O' && avecTip != 'N'; gotoxy(x, y))
			cout << (avecTip = toupper(_getch()));

		tip = 0;
		if (avecTip == 'O')
		{
			cout << setprecision(0)				<< "\n\n"
				<< "Choix du pourboire ?"		<< "\n\n"
				<< "1 = " << TIP1*100 << "%"	<< "\n"
				<< "2 = " << TIP2*100 << "%"	<< "\n"
				<< "3 = " << TIP3*100 << "%"	<< "\n\n"
				<< "4 = en %"					<< "\n"
				<< "5 = en $"					<< "\n\n"
				<< "6 = au hasard entre " << MINTip << "% et " << MAXTip << "%" << "\n\n"
				<< "Choix : ";

			x = wherex(), y = wherey();
			for (choix = '0'; choix < '1' || choix > '6'; gotoxy(x, y))
				cout << (choix = toupper(_getch()));

			cout << endl;
			if (choix == '4')
			{
				cout << endl << "Quel est le % du pourboire ( 0% \x85 30% max ) ? ";
				cin >> TIP4;	// � faire : valider le %
				TIP4 /= 100;
			}
			else if (choix == '5')
			{
				cout << endl << "Quel est le montant du pourboire en $ ( 0$ \x85 100$ max ) ? ";
				cin >> tip;		// � faire : valider le montant $
			}
			else if (choix == '6' )
				TIP4 = ( rand() % ( MAXTip - MINTip + 1 ) + MINTip ) / 100.0;
		}

		// 2) CALCULER LES TAXES ET LE POURBOIRE
		tvq = totalAvantTaxe * TVQ;
		tps = totalAvantTaxe * TPS;
	
		if (avecTip == 'O')
			switch(choix)
			{
				case '1': tip = totalAvantTaxe * TIP1; break;
				case '2': tip = totalAvantTaxe * TIP2; break;
				case '3': tip = totalAvantTaxe * TIP3; break;
				case '4':
				case '6': tip = totalAvantTaxe * TIP4; break; // 4 et 6 utilisent la variable TIP4 pour le calcul
			}

		totalApresTaxe = totalAvantTaxe + tvq + tps + tip;

		// 3) AFFICHER LA FACTURE
		clrscr();
		cout << setprecision(2) << right << endl << endl;
		cout << "D\x82tails de la facture"	<< endl;
		cout << "====================="		<< endl << endl;
		cout << "Montant brute : "			<< totalAvantTaxe	<< " $" << endl << endl;
		cout << " tps : "					<< setw(tab) << tps	<< " $" << endl << endl;
		cout << " tvq : "					<< setw(tab) << tvq	<< " $" << endl << endl;
		
		if (avecTip == 'O')
		{
			cout << " tip : "				<< setw(tab) << tip << " $" << "   qui \x82quivaut \x85 ";
			if (totalAvantTaxe != 0)
				cout << tip / totalAvantTaxe * 100;
			else if (tip != 0)
				cout << "???";
			else
				cout << 0;
			cout << " %" << endl << endl;
		}

		cout << "Montant total : " << totalApresTaxe << " $" << endl;

		// 4) RECOMMENCER POUR UNE AUTRE FACTURE ?
		cout << "\n\n\n\n" << "Voulez-vous calculer une autre facture ? (O/N) : ";
		x = wherex(); y = wherey();
		for (recommencer = ' '; recommencer != 'O' && recommencer != 'N'; gotoxy(x, y))
			cout << (recommencer = toupper(_getch()));

		clrscr();
	}
	while (recommencer == 'O');
}