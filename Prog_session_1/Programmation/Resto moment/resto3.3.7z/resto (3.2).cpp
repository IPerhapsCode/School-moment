/*
	Version		: 3.2
	Description	: Programme qui ajoute les taxes � un montant lu au clavier.
				  Ce programme permet aussi d'ajouter de plusieurs fa�on un pourboire.
				  Ce programme affiche les d�tails des taxes et pourboire ainsi que le total.


	Ajouts		: Permet de sp�cifier le pourboire en $ ou en % directement
				: Exemple de pr�sentation des IF-ELSE imbriqu�s � plat
				: Utilisation de la fonction "toupper"
				: Utilisation du _getche() vs _getch() vs cin lors de la lecture des choix de l'utilisateur

	� Faire     : Validation des donn�es lues � l'entr�e
*/

#include <iostream>	// pour le cout et le cin
#include <iomanip>	// pour les manipulateurs du cout: fixed, setprecision(), setw(), ...
#include <conio.h>	// pour le _getch() et _getche()

#include "../../cvm 21.h"

using namespace std; // Pour ne pas �tre oblig� d'�crire std::cout

int main ()
{
	// CONSTANTES POUR L'AFFICHAGE
	const int tab = 7;

	// CONSTANTES
	const double TVQ = 0.09975, TPS = 0.05, TIP1 = 0.12, TIP2 = 0.15, TIP3 = 0.18;
	const string titre = "D\x82tails de la facture";

	// VARIABLES
    double TIP4;
	double totalAvantTaxe, tps, tvq, tip, totalApresTaxe;
	char r�ponse1, r�ponse2;
    bool avecTip;


	// INPUT
	cout << endl << "Quel est le montant ? : ";
	cin >> totalAvantTaxe;
	
	cout << endl << "Voulez-vous inclure un pourboire ? (O/N) : ";
	r�ponse1 = _getch();
	r�ponse1 = toupper(r�ponse1);
	cout << r�ponse1 << endl;
	avecTip = r�ponse1 == 'O';
   
	tip = 0;
	if (avecTip)
	{
		cout
			<< "\n"	<< "Choix du pourboire ?" << "\n\n"
			<< " 1 = " << TIP1*100 << "%" << "\n"
			<< " 2 = " << TIP2*100 << "%" << "\n"
			<< " 3 = " << TIP3*100 << "%" << "\n\n"
			<< " 4 = en %" << "\n"
			<< " 5 = en $" << "\n\n"
			<< "Choix : ";
		r�ponse2 = _getche();
		cout << endl;
		if ( r�ponse2 == '4' )
		{
            cout << endl << "Quel est le % du pourboire ( 0% \x85 30% max ) ? ";
		    cin >> TIP4;
            TIP4 /= 100;
		}
        else if ( r�ponse2 == '5' )
		{
            cout << endl << "Quel est le montant du pourboire en $ ( 0$ \x85 100$ max ) ? ";
		    cin >> tip;
		}
	}


	// CALCULS DES �L�MENTS DE LA FACTURE
	tvq = totalAvantTaxe * TVQ;
	tps = totalAvantTaxe * TPS;
	
	if (avecTip)
		if (r�ponse2 == '1')
			tip = totalAvantTaxe * TIP1;
		else if (r�ponse2 == '2')
			tip = totalAvantTaxe * TIP2;
		else if (r�ponse2 == '3')
			tip = totalAvantTaxe * TIP3;
        else if (r�ponse2 == '4')
			tip = totalAvantTaxe * TIP4;
//		else if (R�ponse2 == '5') //rien � faire car le tip est d�j� donn� par l'utilisateur
//		else // Si la R�ponse2 n'est pas valide le tip = 0

	totalApresTaxe = totalAvantTaxe + tvq + tps + tip;


	// AFFICHAGE DE LA FACTURE
	clrscr();
	cout << fixed << setprecision(2) << right << "\n\n";
	cout << titre << "\n" << setfill('=') << setw(titre.size()) << "" << setfill(' ') << "\n\n";

	cout << "Montant brute : " << totalAvantTaxe << " $" << "\n\n";
	cout << " tps : " << setw(tab) << tps << " $" << "\n\n";
	cout << " tvq : " << setw(tab) << tvq << " $" << "\n\n";
	if (avecTip)
		cout << " tip : " << setw(tab) << tip << " $" << "\n\n";
	cout << "Montant total : " << totalApresTaxe << " $" << "\n";

	_getch();
}