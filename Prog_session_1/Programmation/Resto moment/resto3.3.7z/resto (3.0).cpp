/*
	Version		: 3.0
	Description	: Programme qui ajoute les taxes � un montant lu au clavier.
				  Ce programme permet aussi d'ajouter un pourboire.
				  Ce programme affiche les d�tails des taxes et pourboire ainsi que le total.

	Ajouts		: Gestion d'un pourboire optionnel de 15%
				: Am�lioration de l'affichage en g�n�ral.
*/

#include <iostream>	// pour le cout et le cin
#include <iomanip>	// pour les manipulateurs du cout: fixed, setprecision(), setw(), ...
#include <conio.h>	// pour le _getch()
#include <string>

using namespace std; // Pour ne pas �tre oblig� d'�crire std::cout

int main ()
{
	// CONSTANTES POUR L'AFFICHAGE
	const int tab = 7;

	// CONSTANTES
	const double TVQ = 0.09975, TPS = 0.05, TIP = 0.15;
	const string titre = "D\x82tails de la facture";

	// VARIABLES
	double totalAvantTaxe, tps, tvq, tip, totalApresTaxe;
	char r�ponse;

	// INPUT
	cout << "Quel est le montant ? : ";
	cin >> totalAvantTaxe;
	cout << endl;
	cout << "Voulez-vous inclure un pourboire ? (O/N) : ";
	cin >> r�ponse;

	// CALCULS DES �L�MENTS DE LA FACTURE
	tvq = totalAvantTaxe * TVQ;
	tps = totalAvantTaxe * TPS;
	
	if (r�ponse == 'O' || r�ponse == 'o')
	{
		tip = totalAvantTaxe * TIP;
	}
	else
	{
		tip = 0;
	}
	totalApresTaxe = totalAvantTaxe + tvq + tps + tip;

	// AFFICHAGE DE LA FACTURE
	cout << fixed << setprecision(2) << right;
	cout << endl << endl;

	cout << titre << endl;
	cout << setfill('=') << setw(titre.size()) <<  "" << setfill(' ') << endl << endl;
	cout << "Montant brute : " << totalAvantTaxe << " $" << endl << endl;
	cout << " tps : " << setw(tab) << tps << " $" << endl << endl;
	cout << " tvq : " << setw(tab) << tvq << " $" << endl << endl;
	cout << " tip : " << setw(tab) << tip << " $" << endl << endl;
	cout << "Montant total : " << totalApresTaxe << " $" << endl;

	_getch();
}