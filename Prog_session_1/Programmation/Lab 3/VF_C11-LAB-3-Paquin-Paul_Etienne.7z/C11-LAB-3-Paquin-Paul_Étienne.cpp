#include <iostream>
#include <iomanip>
#include <string>
#include <conio.h>

#include "../cvm 21.h"

using namespace std;

int main()
{

	//Constante 
	const string TITRE = "HYDRO-QU\220BEC";
	const double TPS = 0.05;
	const double TVQ = 0.09975;
	const double TARIFPARJOUR = 0.42238;
	const double TARIF_1 = 0.06319;
	const double TARIF_2 = 0.09749;

	//Variables
	string prenom;
	string nom;
	unsigned int nbKwHres;
	unsigned int nbJour;
	double prix_1;
	double prix_2;
	double tps;
	double tvq;
	double nbKwHres2;
	double nbKwHres3;
	double redevance;
	double totalFacture;
	
	int x, x2, x3;
	int y = 120/2;

	//Affichage titre 
	cout << fixed << right << setw(y + TITRE.size() / 2) << TITRE << "\n\n\n\n";
	
	//User input
	x = 40;
	cout << left << setw(x) << "Quel est votre pr\x82nom " << ": ";
	getline(cin, prenom);
	cout << "\n" << setw(x) << "Quel est votre nom " << ": ";
	getline(cin, nom);
	cout << "\n\n" << setw(x) <<  "Quelle est votre consommation en kWh " << ": ";
	cin >> nbKwHres;
	cout << "\n" << setw(x) << "Sur combien de jours " << ": ";
	cin >> nbJour;
	cout << "\n\n" << right << setw(y) << "Appuyez sur une touche pour continuer";
	_getch();
	clrscr();

	//Affichage facture
	x = 32, x2 = 13, x3 = 6;

	if(nbKwHres>40*nbJour)
	{
		prix_1 = TARIF_1 * 40 * nbJour;
		prix_2 = (nbKwHres - 40 * nbJour) * TARIF_2;
		nbKwHres2 = 40 * nbJour;
		nbKwHres3 = nbKwHres - 40 * nbJour;
	}
	else 
	{
		prix_1 = TARIF_1 * nbKwHres;
		prix_2 = 0;
		nbKwHres2 = nbKwHres;
		nbKwHres3 = 0;
	}
	redevance = nbJour * TARIFPARJOUR;
	tps = (prix_1 + prix_2 + redevance) * TPS;
	tvq = (prix_1 + prix_2 + redevance) * TVQ;
	totalFacture = redevance + prix_1 + prix_2 + tps + tvq;

	cout << right << setw(y + TITRE.size() / 2) << TITRE << "\n\n\n\n";
	cout << left << "FACTURE D'\x90LECTRICIT\220 DE : " << prenom << " " << nom << "\n\n\n";
	cout << setw(x) << left << setprecision(2) << "REDEVANCE D'ABONNEMENT:" << setw(x2) << right << redevance << setw(x3) << left << setprecision(5) << " $" << nbJour << " jour(s) x " << TARIFPARJOUR << " $" << "\n\n\n";
	cout << setw(x) << "CONSOMMATION:" << setw(x2+x3) << " " << nbKwHres << " kWh" << "\n\n";
	cout << setw(x) << setprecision(2) << "  Les 40 premiers kWh\x5cjour:" << setw(x2) << right << prix_1 << setw(x3) << left << " $" << setprecision(0) << nbKwHres2 << " kWh x " << setprecision(5) << TARIF_1 << " $" << "\n\n";
	cout << setw(x) << setprecision(2) << "  Le reste de la consommation:" << setw(x2) << right << prix_2 << setw(x3) << left << " $" << setprecision(0) << nbKwHres3 << " kWh x " << setprecision(5) << TARIF_2 << " $" << "\n\n\n";
	cout << setw(x) << left << "TPS:" << setw(x2) << right << setprecision(2) << tps << setw(x3) << left << setprecision(0) << " $" << TPS*100 << " %" << "\n\n";
	cout << setw(x) << "TVQ:" << setw(x2) << right << setprecision(2) << tvq << setw(x3) << left << setprecision(3) << " $" << TVQ*100 << " %" << "\n\n";
	cout << setw(x) << " " << "---------------" << "\n";
	cout << setw(x) << setprecision(2) << "TOTAL:" << setw(x2) << right << totalFacture << " $";

	_getch();
}

